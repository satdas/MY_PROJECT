package automationframework;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import utility.Constant;
import utility.ExcelUtils;

public class FirstTestCase {

	public static void main(String[] args) throws Exception {
		
		// Create a new instance of the Firefox driver
		System.setProperty("webdriver.gecko.driver","D:\\Test_Selenium\\geckodriver-v0.20.1-win64\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
				
				
		
				try {
					ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData,"Sheet1");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

				

				int i,j;				
				i=1;j=1;
				while(!ExcelUtils.getCellData(i, 1).equals("") ) {
					
					
			    //Launch of anonymous feedback website
				driver.get(Constant.URL);
				
				//Reading data from spreadsheet
				String username = ExcelUtils.getCellData(i, j);
				String password = ExcelUtils.getCellData(i, j+1);
				String another_username = ExcelUtils.getCellData(i, j+2); 
				String feedback1 = ExcelUtils.getCellData(i, j+3);
				
				//Click Log in link
				WebElement login_link = driver.findElement(By.xpath("/html/body/div[2]/div/div[3]/div[1]/ul[2]/li[2]/a"));
				login_link.click();
				
				//Enter username
				WebElement usernm = driver.findElement(By.xpath("//*[@id='fburl_d']"));
				usernm.sendKeys(username);
				
				//Enter password
				WebElement passwd = driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/form[2]/div/input[1]"));
				passwd.sendKeys(password);
				
				//Click Log In button
				WebElement login_btn = driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/form[2]/div/button"));
				login_btn.submit();
				Thread.sleep(5000);
				//WebElement frnds = driver.findElement(By.xpath("/html/body/div[6]/div[1]/ul/li[4]/a"));
				//frnds.click();
				//WebElement frnd1 = driver.findElement(By.xpath("/html/body/div[6]/div[2]/div/ul/li/div[2]/a"));
				//frnd1.click();
				
				//Search another user name/friend
				WebElement frnd_search = driver.findElement(By.xpath("/html/body/nav[1]/div/div[1]/div[3]/div[2]/div/input"));
				frnd_search.sendKeys(another_username);
				Thread.sleep(2000);
				
				//Click the first user in the result displayed after search 
				WebElement frnd_srch_result = driver.findElement(By.xpath("/html/body/nav[1]/ul[1]/li/div/a"));
				//WebElement frnd_srch_result = driver.findElement(By.cssSelector("li:nth-child(1).ui-menu-item >div>a[href^='/satya']"));
				frnd_srch_result.click();
				
				//Feedback screen opened , now feedback is entered
				WebElement feedback = driver.findElement(By.xpath("/html/body/div[6]/div/div/div/ul/li[1]/form/textarea"));
				feedback.sendKeys(feedback1);
				
				//Click the button - Say it -  to send feedback 
				WebElement sayit_btn = driver.findElement(By.xpath("/html/body/div[6]/div/div/div/ul/li[1]/form/div/button"));
				sayit_btn.click();
				
				//Sent page arrived
				WebElement savedmsg = driver.findElement(By.xpath("/html/body/div[6]/div[2]/div/ul/li[1]/div[2]"));
				System.out.println("Saved message displayed in SENT page: " + savedmsg.getText());
				
				ExcelUtils.setCellData(savedmsg.getText(), i, j+4);
				
				//Click Menu button in the extreme right corner of screen
				WebElement menu = driver.findElement(By.xpath("/html/body/nav[1]/div/div[1]/div[1]/div/button"));
				menu.click();
				
				//Click the Log out link from the list displayed
				WebElement logout = driver.findElement(By.xpath("/html/body/nav[2]/div/div/div/ul/li[3]/a"));
				logout.click();
		 
				
				
				//Wait for 5 Sec
				Thread.sleep(5000);
				
				i++;
			}
		        // Close the driver
		        driver.quit();

	}

}
