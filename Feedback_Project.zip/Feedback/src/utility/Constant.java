package utility;

public class Constant {

	
		 public static  final String URL = "https://kask6iktundubkorras.sayat.me/";
		  
		 public static final String Path_TestData = "D://Test_Selenium//";
	 
		 public static final String File_TestData = "data_driven_test.xlsx";

}
